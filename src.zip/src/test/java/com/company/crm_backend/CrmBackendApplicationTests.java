package com.company.crm_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
